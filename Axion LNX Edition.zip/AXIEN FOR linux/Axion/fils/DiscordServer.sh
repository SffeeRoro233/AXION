#!/usr/bin/env bash

xdg-open "https://discord.gg/fBrMY7b3sv" >/dev/null 2>&1 &

exit 0