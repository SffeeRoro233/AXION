#!/usr/bin/env bash

xdg-open "https://www.roblox.com/home" >/dev/null 2>&1 &

exit 0