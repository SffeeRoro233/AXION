#!/usr/bin/env bash

xdg-open "https://www.youtube.com/@SCRIPTHUB4FR" >/dev/null 2>&1 &

exit 0