#!/usr/bin/env bash

xdg-open "https://scripthub.framer.website" >/dev/null 2>&1 &

exit 0