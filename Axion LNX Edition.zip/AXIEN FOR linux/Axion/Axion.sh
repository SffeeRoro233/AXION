#!/usr/bin/env bash

# =========================
# AXION - Linux Version
# by ScripthubDev
# =========================

printf '\033]0;Axion - by ScripthubDev\007'

RESET="\033[0m"
WHITE="\033[97m"
GRAY="\033[90m"
PINK="\033[38;2;255;20;160m"
RED="\033[38;2;255;35;110m"

open_url() {
    if command -v xdg-open >/dev/null 2>&1; then
        xdg-open "$1" >/dev/null 2>&1 &
    elif command -v gio >/dev/null 2>&1; then
        gio open "$1" >/dev/null 2>&1 &
    else
        echo "Unable to open the link automatically."
        echo "$1"
    fi
}

banner() {
    echo
    printf "                           \033[38;2;255;25;70m╔════════════════════════════════════════════════════════════╗${RESET}\n"
    printf "                           \033[38;2;255;25;80m║${RESET}                                                            \033[38;2;255;25;80m║${RESET}\n"

    printf "                           \033[38;2;255;30;90m║${RESET}         \033[38;2;255;30;90m▄▄▄      ▒██   ██▒ ██▓ ▒█████   ███▄    █${RESET}          \033[38;2;255;30;90m║${RESET}\n"
    printf "                           \033[38;2;255;25;120m║${RESET}         \033[38;2;255;25;120m▒████▄    ▒▒ █ █ ▒░▓██▒▒██▒  ██▒ ██ ▀█   █${RESET}         \033[38;2;255;25;120m║${RESET}\n"
    printf "                           \033[38;2;240;20;155m║${RESET}        \033[38;2;240;20;155m▒██  ▀█▄  ░░  █   ░▒██▒▒██░  ██▒▓██  ▀█ ██▒${RESET}         \033[38;2;240;20;155m║${RESET}\n"
    printf "                           \033[38;2;215;20;190m║${RESET}        \033[38;2;215;20;190m░██▄▄▄▄██  ░ █ █ ▒ ░██░▒██   ██░▓██▒  ▐▌██▒${RESET}         \033[38;2;215;20;190m║${RESET}\n"
    printf "                           \033[38;2;185;25;220m║${RESET}         \033[38;2;185;25;220m▓█   ▓██▒▒██▒ ▒██▒░██░░ ████▓▒░▒██░   ▓██░${RESET}         \033[38;2;185;25;220m║${RESET}\n"
    printf "                           \033[38;2;155;30;235m║${RESET}         \033[38;2;155;30;235m▒▒   ▓▒█░▒▒ ░ ░▓ ░░▓  ░ ▒░▒░▒░ ░ ▒░   ▒ ▒${RESET}          \033[38;2;155;30;235m║${RESET}\n"
    printf "                           \033[38;2;120;35;245m║${RESET}         \033[38;2;120;35;245m▒   ▒▒ ░░░   ░▒ ░ ▒ ░  ░ ▒ ▒░ ░ ░░   ░ ▒░${RESET}          \033[38;2;120;35;245m║${RESET}\n"
    printf "                           \033[38;2;95;45;255m║${RESET}          \033[38;2;95;45;255m░   ▒    ░    ░   ▒ ░░ ░ ░ ▒     ░   ░ ░${RESET}          \033[38;2;95;45;255m║${RESET}\n"
    printf "                           \033[38;2;75;55;255m║${RESET}              \033[38;2;75;55;255m░  ░ ░    ░   ░      ░ ░           ░${RESET}          \033[38;2;75;55;255m║${RESET}\n"

    printf "                           \033[38;2;125;30;220m║${RESET}                                                            \033[38;2;125;30;220m║${RESET}\n"
    printf "                           \033[38;2;220;25;180m║${RESET}                       \033[38;2;255;25;150m[ScripthubDev]${RESET}                       \033[38;2;220;25;180m║${RESET}\n"
    printf "                           \033[38;2;155;30;230m║${RESET}                                                            \033[38;2;155;30;230m║${RESET}\n"
    printf "                           \033[38;2;110;40;255m╚════════════════════════════════════════════════════════════╝${RESET}\n"
}

while true; do
    clear
    banner

    echo
    printf "                                             ${PINK}Simple Multi-Tool${RESET}\n"
    printf "                                      ${GRAY}https://github.com/SffeeRoro233/AXION${RESET}\n"
    echo

    printf "                ${PINK}┌──────────────────────────┬──────────────────────────┬──────────────────────────┐${RESET}\n"
    printf "                ${PINK}│${WHITE}         INTERNET         ${PINK}│${WHITE}     SOCIAL NETWORKS      ${PINK}│${WHITE}       APPLICATIONS       ${PINK}│${RESET}\n"
    printf "                ${PINK}├──────────────────────────┼──────────────────────────┼──────────────────────────┤${RESET}\n"

    printf "                ${PINK}│ ${PINK}[01]${WHITE} Website             ${PINK}│ ${PINK}[05]${WHITE} Discord             ${PINK}│ ${PINK}[09]${WHITE} Roblox              ${PINK}│${RESET}\n"
    printf "                ${PINK}│ ${PINK}[02]${GRAY} Coming Soon...      ${PINK}│ ${PINK}[06]${WHITE} YouTube             ${PINK}│ ${PINK}[10]${GRAY} Coming Soon...      ${PINK}│${RESET}\n"
    printf "                ${PINK}│ ${PINK}[03]${GRAY} Coming Soon...      ${PINK}│ ${PINK}[07]${GRAY} Coming Soon...      ${PINK}│ ${PINK}[11]${GRAY} Coming Soon...      ${PINK}│${RESET}\n"
    printf "                ${PINK}│ ${PINK}[04]${GRAY} Coming Soon...      ${PINK}│ ${PINK}[08]${GRAY} Coming Soon...      ${PINK}│ ${PINK}[12]${GRAY} Coming Soon...      ${PINK}│${RESET}\n"

    printf "                ${PINK}└──────────────────────────┴──────────────────────────┴──────────────────────────┘${RESET}\n"

    printf "                                                                                           ${RED}[E] Exit${RESET}\n"
    printf "                                            ${PINK}AXION ${GRAY}> ${WHITE}"
    read -r input
    printf "${RESET}"

    case "${input,,}" in
        1|01)
            open_url "https://github.com/SffeeRoro233/AXION"
            ;;

        5|05)
            open_url "https://discord.gg/fBrMY7b3sv"
            ;;

        6|06)
            open_url "https://www.youtube.com"
            ;;

        9|09)
            open_url "https://www.roblox.com"
            ;;

        e)
            clear
            exit 0
            ;;
    esac
done